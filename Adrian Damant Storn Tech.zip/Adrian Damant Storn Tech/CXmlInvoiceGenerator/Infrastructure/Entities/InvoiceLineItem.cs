﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CXmlInvoiceGenerator.Infrastructure.Entities
{
    internal class InvoiceLineItem
    {
        public int Id { get; set; }
        public string InvoiceId { get; set; }
        public string StockItemId { get; set; }
        public string Manufacturer { get; set; }
        public string PartNo { get; set; }
        public string Description { get; set; }
        public string Qty { get; set; }
        public string UnitPrice { get; set; }
        public string LineTotal { get; set; }
    }
}
