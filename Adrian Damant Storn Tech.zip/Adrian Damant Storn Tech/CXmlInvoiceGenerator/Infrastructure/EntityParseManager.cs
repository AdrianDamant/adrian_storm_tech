﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CXmlInvoiceGenerator.Infrastructure.Entities;

namespace CXmlInvoiceGenerator.helpers
{
    internal class EntityParseManager
    {
        //Parse each DataTable Value into Classes//
        //Take in DataTable returned from the datasource, and return a usable entity class//

        public static List<Invoice> ParseInvoices(DataTable dataTableInvoices)
        {
            var output = new List<Invoice>();
            foreach (DataRow row in dataTableInvoices.Rows)
            {
                output.Add(new Invoice
                {
                    Id = int.Parse(row["Id"].ToString()),
                    CustomerId = int.Parse(row["CustomerId"].ToString()),
                    SalesOrderId = int.Parse(row["SalesOrderId"].ToString()),
                    CurrencyCode = row["CurrencyCode"].ToString(),
                    NetAmount = row["NetAmount"].ToString(),
                    VATAmount = row["VATAmount"].ToString(),
                    GrossAmount = row["GrossAmount"].ToString(),
                    VATCode = row["VATCode"].ToString(),
                    VATPercentage = row["VATPercentage"].ToString(),
                    PaymentTermsDays = row["PaymentTermsDays"].ToString()
                });
            }
            return output;
        }

        public static List<InvoiceLineItem> ParseInvoiceLineItems(DataTable dataTableInvoices)
        {
            var output = new List<InvoiceLineItem>();
            foreach (DataRow row in dataTableInvoices.Rows)
            {
                output.Add(new InvoiceLineItem
                {
                    Id = int.Parse(row["Id"].ToString()),
                    InvoiceId = row["InvoiceId"].ToString(),
                    StockItemId = row["StockItemId"].ToString(),
                    Manufacturer = row["Manufacturer"].ToString(),
                    PartNo = row["PartNo"].ToString(),
                    Description = row["Description"].ToString(),
                    Qty = row["Qty"].ToString(),
                    UnitPrice = row["UnitPrice"].ToString(),
                    LineTotal = row["LineTotal"].ToString()
                });
            }
            return output;
        }

        public static Address ParseAddress(DataRow dataRowInvoices)
        {
            var output = new List<Address>();
            output.Add(new Address
            {
                ContactName = dataRowInvoices["ContactName"].ToString(),
                AddrLine1 = dataRowInvoices["AddrLine1"].ToString(),
                AddrLine2 = dataRowInvoices["AddrLine2"].ToString(),
                AddrLine3 = dataRowInvoices["AddrLine3"].ToString(),
                AddrLine4 = dataRowInvoices["AddrLine4"].ToString(),
                AddrLine5 = dataRowInvoices["AddrLine5"].ToString(),
                AddrPostCode = dataRowInvoices["AddrPostCode"].ToString(),
                CountryCode = dataRowInvoices["CountryCode"].ToString(),
                Country = dataRowInvoices["Country"].ToString()
            });
            return output[0];
        }
    }
}
